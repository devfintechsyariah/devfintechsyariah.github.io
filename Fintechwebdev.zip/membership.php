<?php require('header.php'); ?>

    <!-- Heder Jumbotron -->
    <header>
        <div class="jumbotron" id="jumboabout1">
        <!-- <div class="container">
            <h3>Kolaborasi Ekosistem Teknologi Keuangan</h3>
            <p>dari perusahaan Indonesia untuk masyarakat Indonesia</p>
            <br><br>
            <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>  <a class="btn btn-default btn-lg" href="#" role="button">Apply for Membership</a></p>
        </div> -->
        </div>
    </header>
    <!-- Page Content -->
    <!-- Count   -->
    <div class="container-fluid" id="subtittle2">
      <div class="col-md-8 col-md-offset-2 text-center">
      <h3><strong>BERGABUNG MENJADI ANGGOTA</strong></h3>
      <hr width="10%" style="border: 2px solid #1BB6AD">
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, neque corrupti quod. Veritatis itaque sapiente impedit omnis culpa quaerat vitae velit eligendi odio doloremque illum corporis blanditiis adipisci, vel modi? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, neque corrupti quod. Veritatis itaque sapiente impedit omnis culpa quaerat vitae velit eligendi odio doloremque illum corporis blanditiis adipisci,</p>
    <a class="btn btn-primary btn-lg" href="apply" role="button">Apply for Membership</a>
    <br><br><br><br>
    </div>
    </div>
     <div class="container-fluid" id="subtittle5">
      <div class="col-md-8 col-md-offset-2 text-center">
      <h3><strong>MANFAAT MENJADI ANGGOTA</strong></h3>
      <hr width="10%" style="border: 2px solid #1BB6AD">
       <p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, neque corrupti quod. Veritatis itaque sapiente impedit omnis culpa quaerat vitae velit eligendi odio doloremque illum corporis blanditiis adipisci, vel modi? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad tempore iste dolor veritatis, odit cumque nisi doloribus sed aliquid excepturi blanditiis aut hic harum consequuntur, labore repellat distinctio voluptas nobis.Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      <br><br>
            <div class="row">
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis pariatur ea enim illo itaque corporis, eos facere quibusdam ratione excepturi vel beatae ducimus voluptate maxime harum! Voluptatibus quibusdam velit in.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis at recusandae minima vel itaque similique, fugiat quos, quo dolore beatae ratione quasi suscipit! Error optio, ea consequatur modi labore provident.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis quae corporis quam illo recusandae praesentium aut nihil ad id. Exercitationem ipsa soluta recusandae sed minus officiis, quod laborum! Quia, nisi.</p></div>
            </div>
        <br><br>
            <div class="row">
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis pariatur ea enim illo itaque corporis, eos facere quibusdam ratione excepturi vel beatae ducimus voluptate maxime harum! Voluptatibus quibusdam velit in.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis at recusandae minima vel itaque similique, fugiat quos, quo dolore beatae ratione quasi suscipit! Error optio, ea consequatur modi labore provident.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis quae corporis quam illo recusandae praesentium aut nihil ad id. Exercitationem ipsa soluta recusandae sed minus officiis, quod laborum! Quia, nisi.</p></div>
            </div>
      </div>
    </div>
    <div class="container-fluid" id="subtittle3">
      <div class="col-md-8 col-md-offset-2 text-center">
      <h3><strong>JENIS KEANGGOTAAN</strong></h3>
      <hr width="10%" style="border: 2px solid #1BB6AD">
      <p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, neque corrupti quod. Veritatis itaque sapiente impedit omnis culpa quaerat vitae velit eligendi odio doloremque illum corporis blanditiis adipisci, vel modi? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad tempore iste dolor veritatis, odit cumque nisi doloribus sed aliquid excepturi blanditiis aut hic harum consequuntur, labore repellat distinctio voluptas nobis.Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      <br><br>
            <div class="row">
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis pariatur ea enim illo itaque corporis, eos facere quibusdam ratione excepturi vel beatae ducimus voluptate maxime harum! Voluptatibus quibusdam velit in.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Facilis at recusandae minima vel itaque similique, fugiat quos, quo dolore beatae ratione quasi suscipit! Error optio, ea consequatur modi labore provident.</p></div>
                <div class="col-md-4"><img src="img/thumb2.jpg" alt="" class="img-circle" style="border: 3px solid #F3F5F9"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis quae corporis quam illo recusandae praesentium aut nihil ad id. Exercitationem ipsa soluta recusandae sed minus officiis, quod laborum! Quia, nisi.</p></div>
            </div>
        <p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium, neque corrupti quod. Veritatis itaque sapiente impedit omnis culpa quaerat vitae velit eligendi odio doloremque illum corporis blanditiis adipisci, vel modi? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad tempore iste dolor veritatis, odit cumque nisi doloribus sed aliquid excepturi blanditiis aut hic harum consequuntur, labore repellat distinctio voluptas nobis.Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
      </div>
    </div>
    <div class="container-fluid" id="subtittle2">
      <div class="col-md-8 col-md-offset-2 text-center">
      <h3><strong>TERTARIK BERGABUNG ?</strong></h3>
      <hr width="5%" style="border: 2px solid #1BB6AD">
    <a class="btn btn-primary btn-lg" style="margin-right: 0; padding: 10px 100px;" href="apply" role="button">Apply</a>
    <br><br><br><br>
    </div>
    </div>
<?php require('footer.php'); ?>

