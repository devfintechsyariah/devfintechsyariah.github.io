<?php require('header.php'); ?>
    <!-- Heder Jumbotron -->
    <header>
    <div class="container-fluid" id="subtittle4">
      <div class="col-md-8 col-md-offset-2 text-center">
      <h3><strong></strong></h3>
      <hr width="10%" style="border: 2px solid #1BB6AD">
      </div>
    </div>
    </header>
    <!-- Page Content -->
    <div class="container">
    <div class="col-md-8 col-md-offset-2">
       <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdjgpA5YUTFa_TpURkwuKB4kOYMgDQVJIsrRg1VA55F9zv8FA/viewform?embedded=true" width="760" height="600" frameborder="0" marginheight="0" marginwidth="0">Mohon Tunggu...</iframe>
        </div>
    </div>

<?php require('footer.php'); ?>