<?php require('header.php'); ?>

    <!-- Heder Jumbotron -->
    <header>
        <div class="jumbotron" id="jumboabout1">
        <!-- <div class="container">
            <h3>Kolaborasi Ekosistem Teknologi Keuangan</h3>
            <p>dari perusahaan Indonesia untuk masyarakat Indonesia</p>
            <br><br>
            <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>  <a class="btn btn-default btn-lg" href="#" role="button">Apply for Membership</a></p>
        </div> -->
        </div>
    </header>
    <!-- Page Content -->
   <div class="jumbotron" id="jumbotron2">
        <div class="container">
        <div class="col-md-12">
            <div class="col-md-6">
                <h3><strong>UPCOMING EVENT</strong></h3>
                <!-- <p>Fintech Days 2018</p>
                <div class="row">
                    <div class="col-md-1"><h5><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span></h5></div>
                    <div class="col-md-11"><h5> 15 Mar 2018 08.00 - 17 Mar 2018 17.00</h5></div>
                </div>
                 <div class="row">
                    <div class="col-md-1"><h5><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span></h5></div>
                    <div class="col-md-11"><h5> Hotel Novotel Makassar Grand Shayla, Jalan Chairil Anwar No.28, Sawarigading, Ujung Padang, Kota Makassar, Sulawesi Selatan.</h5></div>
                </div>
                 <div class="row">
                    <div class="col-md-1"><h5><span class="glyphicon glyphicon-ok" aria-hidden="true"></span></h5></div>
                    <div class="col-md-11"><h5> Gratis untuk umum</h5></div>
                </div> -->
                <br>
                <p><a class="btn btn-primary btn-lg" href="#" role="button">Coming Soon</a>
            </div>
            <div class="col-md-6"><img src="img/event1.png" alt=""></div>
        </div>
        </div>
    </div>
    <div class="container" id="post">
    <div class="row">
        <div class="col-md-12">
            <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
             <img src="img/thumb2.jpg" alt="">
                <div class="caption">
                <h3>Thumbnail label</h3>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <div class="text-center"><a href="#" class="btn btn-primary" role="button">Read</a></div>
                </div>
            </div>
            </div>
            <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
             <img src="img/thumb2.jpg" alt="">
                <div class="caption">
                <h3>Thumbnail label</h3>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <div class="text-center"><a href="#" class="btn btn-primary" role="button">Read</a></div>
                </div>
            </div>
            </div>
            <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
             <img src="img/thumb2.jpg" alt="">
                <div class="caption">
                <h3>Thumbnail label</h3>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <div class="text-center"><a href="#" class="btn btn-primary" role="button">Read</a></div>
                </div>
            </div>
            </div>
            <div class="col-xs-6 col-md-3">
            <div class="thumbnail">
             <img src="img/thumb2.jpg" alt="">
                <div class="caption">
                <h3>Thumbnail label</h3>
                <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                <div class="text-center"><a href="#" class="btn btn-primary" role="button">Read</a></div>
                </div>
            </div>
            </div>
        </div>
        </div>
        <div class="col-md-12 text-center">
        <br>
        <a class="btn btn-primary btn-lg" href="#" role="button">See More</a>
        </div>
    </div>
    <?php require('footer.php'); ?>